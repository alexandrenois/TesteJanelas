package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class AgendaController implements ActionListener{
	
	private JTextField txNome;
	private JTextField txFone;
	private JComboBox<String> cbTipoFone; 
	private JRadioButton rbFamilia, rbAmigos;
	private JButton btnSalvar;
	
	private AgendaController (JTextField txNome, JTextField txFone, JComboBox<String> cbTipoFone,
			JRadioButton rbFamilia, JRadioButton rbAmigos) {
		this.txNome = txNome;
		this.txFone = txFone;
		this.cbTipoFone = this.cbTipoFone;
		this.rbFamilia = rbFamilia;
		this.rbAmigos = rbAmigos;
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}

}
