package view;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;

public class telaAgenda extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txNome;
	private JTextField txFone;
	private JComboBox<String> cbTipoFone; 
	private JRadioButton rbFamilia, rbAmigos;
	private JButton btnSalvar;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					telaAgenda frame = new telaAgenda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public telaAgenda() {
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 373, 250);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNome = new JLabel("Nome:");
		lblNome.setBounds(10, 11, 46, 14);
		contentPane.add(lblNome);
		
		txNome = new JTextField();
		txNome.setBounds(65, 8, 86, 20);
		contentPane.add(txNome);
		txNome.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone:");
		lblTelefone.setBounds(10, 42, 46, 14);
		contentPane.add(lblTelefone);
		
		txFone = new JTextField();
		txFone.setBounds(143, 39, 86, 20);
		contentPane.add(txFone);
		txFone.setColumns(10);
		
		cbTipoFone = new JComboBox();
		cbTipoFone.setBounds(65, 39, 68, 20);
		contentPane.add(cbTipoFone);
		cbTipoFone.addItem("Celular");
		cbTipoFone.addItem("Fixo");
		
		rbFamilia = new JRadioButton("Familia ");
		rbFamilia.setBounds(21, 72, 88, 23);
		contentPane.add(rbFamilia);
		rbFamilia.setSelected(true);
		
		rbAmigos = new JRadioButton("Amigos");
		rbAmigos.setBounds(111, 72, 73, 23);
		contentPane.add(rbAmigos);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rbAmigos);
		bg.add(rbFamilia);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.setBounds(230, 157, 89, 23);
		contentPane.add(btnSalvar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(47, 157, 89, 23);
		contentPane.add(btnCancelar);
	}
}
